﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

class Program
{
    private static TcpListener server;
    private static readonly List<TcpClient> clients = new List<TcpClient>();
    private static readonly int port = 5388;
    private static readonly string pcName = Environment.MachineName;

    static async Task Main(string[] args)
    {
        Console.Title = "RC7 Chat Server";
        Console.WriteLine("Starting server, waiting for clients...");

        try
        {
            server = new TcpListener(IPAddress.Any, port);
            server.Start();
            Console.WriteLine("Server started successfully!");
        }
        catch (SocketException ex)
        {
            Console.WriteLine("Chat app is unavailable now. Try later.");
            await Task.Delay(3000);
            return;
        }

        try
        {
            while (true)
            {
                TcpClient client = await server.AcceptTcpClientAsync();
                lock (clients)
                {
                    clients.Add(client);
                }
                Console.WriteLine("Client connected!");
                _ = Task.Run(() => HandleClientAsync(client));
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
        finally
        {
            foreach (var client in clients)
            {
                client?.Close();
            }
            server?.Stop();
            Console.WriteLine("Server stopped. Press any key to exit.");
            Console.ReadKey();
        }
    }

    static async Task HandleClientAsync(TcpClient client)
    {
        NetworkStream stream = null;
        try
        {
            stream = client.GetStream();
            await Task.WhenAll(ReceiveMessages(client, stream), SendMessages(client, stream));
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Client error: {ex.Message}");
        }
        finally
        {
            lock (clients)
            {
                clients.Remove(client);
            }
            stream?.Dispose();
            client?.Close();
            Console.WriteLine("Client disconnected.");
        }
    }

    static async Task ReceiveMessages(TcpClient client, NetworkStream stream)
    {
        byte[] buffer = new byte[1024];
        while (true)
        {
            try
            {
                int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                if (bytesRead == 0)
                {
                    Console.WriteLine("Client disconnected.");
                    break;
                }
                string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                Console.WriteLine(message);
                await BroadcastMessage(message, client);
            }
            catch
            {
                break;
            }
        }
    }

    static async Task SendMessages(TcpClient client, NetworkStream stream)
    {
        while (true)
        {
            try
            {
                string message = Console.ReadLine();
                if (string.IsNullOrEmpty(message)) continue;
                string formattedMessage = $"SERVER-{pcName}: {message}";
                await BroadcastMessage(formattedMessage, null);
                Console.WriteLine($"Sent: {formattedMessage}");
            }
            catch
            {
                break;
            }
        }
    }

    static async Task BroadcastMessage(string message, TcpClient sender)
    {
        byte[] data = Encoding.UTF8.GetBytes(message);
        lock (clients)
        {
            foreach (var client in clients)
            {
                if (client != sender && client.Connected)
                {
                    try
                    {
                        NetworkStream stream = client.GetStream();
                        if (stream.CanWrite)
                        {
                            stream.WriteAsync(data, 0, data.Length).GetAwaiter().GetResult();
                            stream.FlushAsync().GetAwaiter().GetResult();
                        }
                    }
                    catch
                    {
                        // Handle client disconnection silently
                    }
                }
            }
        }
    }
}