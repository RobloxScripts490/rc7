﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace RC7Chat
{
    class ChatClient
    {
        static object consoleLock = new object();
        static string username = "";
        static bool cleaningVoteActive = false;

        static void Main(string[] args)
        {
            Console.Title = "RC7 Chat";  // Pencere başlığını değiştir

            Console.Write("Type your name: ");
            username = Console.ReadLine();

            try
            {
                TcpClient client = new TcpClient();
                var connectTask = client.ConnectAsync("important-coaching.gl.at.ply.gg", 5388);
                bool connected = connectTask.Wait(5000); // 5 saniye timeout

                if (!connected)
                {
                    ShowServerUnavailableAndExit();
                    return;
                }

                NetworkStream stream = client.GetStream();

                byte[] nameBytes = Encoding.UTF8.GetBytes(username + "\n");
                stream.Write(nameBytes, 0, nameBytes.Length);

                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("Welcome to RC7 Chat!");
                Console.WriteLine("Type /online to see how many people are online.");
                Console.WriteLine("Type /clear to send others a chat clear request.\n");
                Console.ResetColor();

                Thread receiveThread = new Thread(() =>
                {
                    byte[] buffer = new byte[1024];
                    int bytesRead;

                    try
                    {
                        while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0)
                        {
                            string message = Encoding.UTF8.GetString(buffer, 0, bytesRead).Trim();

                            if (message == "/clear")
                            {
                                // Chat temizleme komutu geldi
                                lock (consoleLock)
                                {
                                    Console.Clear();
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    Console.WriteLine("Welcome to RC7 Chat!");
                                    Console.WriteLine("Type /online to see how many people are online.\n");
                                    Console.ResetColor();
                                }
                                cleaningVoteActive = false;
                                continue;
                            }

                            // Oy mesajı geldiğinde oy moduna geç
                            if (message.StartsWith("Server: \"") && message.Contains("Wants to clean chat"))
                            {
                                cleaningVoteActive = true;
                            }

                            lock (consoleLock)
                            {
                                if (message.StartsWith("Server:"))
                                    Console.ForegroundColor = ConsoleColor.Yellow;
                                else if (message.StartsWith(username + ":"))
                                    Console.ForegroundColor = ConsoleColor.Green;
                                else
                                    Console.ForegroundColor = ConsoleColor.White;

                                Console.WriteLine(message);
                                Console.ResetColor();
                            }
                        }
                    }
                    catch
                    {
                        // Server bağlantısı kesilirse burada yakalanabilir
                        ShowServerUnavailableAndExit();
                    }
                });

                receiveThread.IsBackground = true;
                receiveThread.Start();

                while (true)
                {
                    string input = Console.ReadLine();

                    if (string.IsNullOrWhiteSpace(input))
                        continue; // Boş mesaj engeli

                    // Oy oylaması sırasında sadece A veya D kabul et
                    if (cleaningVoteActive)
                    {
                        if (input.Equals("A", StringComparison.OrdinalIgnoreCase) || input.Equals("D", StringComparison.OrdinalIgnoreCase))
                        {
                            byte[] voteBytes = Encoding.UTF8.GetBytes(input + "\n");
                            stream.Write(voteBytes, 0, voteBytes.Length);

                            if (input.Equals("A", StringComparison.OrdinalIgnoreCase))
                            {
                                lock (consoleLock)
                                {
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    Console.WriteLine("You accepted the chat cleaning.");
                                    Console.ResetColor();
                                }
                            }
                            else
                            {
                                lock (consoleLock)
                                {
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    Console.WriteLine("You declined the chat cleaning.");
                                    Console.ResetColor();
                                }
                            }
                            continue;
                        }
                        else
                        {
                            lock (consoleLock)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("During the cleaning vote, please answer with A to accept or D to decline.");
                                Console.ResetColor();
                            }
                            continue;
                        }
                    }

                    // Normal mesaj gönder
                    byte[] msgBytes = Encoding.UTF8.GetBytes(input + "\n");
                    stream.Write(msgBytes, 0, msgBytes.Length);
                }
            }
            catch
            {
                ShowServerUnavailableAndExit();
            }
        }

        static void ShowServerUnavailableAndExit()
        {
            lock (consoleLock)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("RC7 Chat is unavailable now. Try again later.");
                Console.ResetColor();
            }
            Thread.Sleep(3000);
            Environment.Exit(0);
        }
    }
}
