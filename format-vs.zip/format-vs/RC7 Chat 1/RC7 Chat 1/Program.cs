﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace RC7Chat
{
    class Server
    {
        static TcpListener listener;
        static List<ClientHandler> clients = new List<ClientHandler>();
        static object clientLock = new object();

        static void Main()
        {
            Console.WriteLine("RC7 Chat Server starting...");
            listener = new TcpListener(IPAddress.Any, 5388); // Listen on all IPs
            listener.Start();
            Console.WriteLine("Listening on port 5388...");

            while (true)
            {
                TcpClient client = listener.AcceptTcpClient();
                ClientHandler handler = new ClientHandler(client);
                lock (clientLock)
                {
                    clients.Add(handler);
                }
                new Thread(handler.Run).Start();
            }
        }

        class ClientHandler
        {
            TcpClient client;
            public NetworkStream stream;
            public string name;

            public ClientHandler(TcpClient client)
            {
                this.client = client;
            }

            public void Run()
            {
                try
                {
                    stream = client.GetStream();
                    byte[] buffer = new byte[1024];
                    int bytesRead = stream.Read(buffer, 0, buffer.Length);
                    string requestedName = Encoding.UTF8.GetString(buffer, 0, bytesRead).Trim();

                    name = GetUniqueName(requestedName);
                    SendToClient($"Server: You are now known as '{name}'");
                    Broadcast($"Server: {name} has joined the chat.");

                    while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) != 0)
                    {
                        string rawMessage = Encoding.UTF8.GetString(buffer, 0, bytesRead).Trim();

                        if (string.IsNullOrWhiteSpace(rawMessage))
                            continue;

                        if (rawMessage == "/online")
                        {
                            Broadcast($"Server: {clients.Count} People Online.");
                        }
                        else
                        {
                            Broadcast($"{name}: {rawMessage}");
                        }
                    }
                }
                catch
                {
                    Console.WriteLine($"{name} disconnected.");
                }
                finally
                {
                    lock (clientLock)
                    {
                        clients.Remove(this);
                    }
                    Broadcast($"Server: {name} has left the chat.");
                    client.Close();
                }
            }

            void SendToClient(string msg)
            {
                byte[] data = Encoding.UTF8.GetBytes(msg + "\n");
                try { stream.Write(data, 0, data.Length); } catch { }
            }

            void Broadcast(string msg)
            {
                byte[] data = Encoding.UTF8.GetBytes(msg + "\n");
                lock (clientLock)
                {
                    foreach (var cl in clients)
                    {
                        try { cl.stream.Write(data, 0, data.Length); } catch { }
                    }
                }
            }

            string GetUniqueName(string baseName)
            {
                string finalName = baseName;
                int suffix = 2;

                lock (clientLock)
                {
                    while (clients.Exists(c => c.name == finalName))
                    {
                        finalName = $"{baseName} ({suffix})";
                        suffix++;
                    }
                }

                return finalName;
            }
        }
    }
}
