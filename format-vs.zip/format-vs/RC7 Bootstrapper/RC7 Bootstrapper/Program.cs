﻿using Newtonsoft.Json.Linq;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net.Http;
using System.Security.AccessControl;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    const string InfoUrl = "https://raw.githubusercontent.com/RobloxScripts490/rc7/refs/heads/main/z";
    const string RbxVersionUrl = "https://clientsettings.roblox.com/v2/client-version/WindowsPlayer/channel/live";
    const string RC7Path = @"C:\RC7";
    const string RC7Exe = @"C:\RC7\RC7.exe";

    static async Task Main()
    {
        try
        {
            await SetConsoleTitleFromJson();
            PrintAsciiArt();
            Console.WriteLine("\n[+] fetching version info...");

            string info = await HttpGet(InfoUrl);
            if (string.IsNullOrEmpty(info))
            {
                Console.WriteLine("[+] failed to fetch version info, starting download...");
                await ProceedToDownload(null);
                return;
            }

            JObject infoJson;
            try
            {
                infoJson = JObject.Parse(info);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[+] invalid version info: {ex.Message}, starting download...");
                await ProceedToDownload(null);
                return;
            }

            if (infoJson["Status"]?.ToString() == "False")
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("[+] RC7 is currently down");
                Thread.Sleep(5000);
                return;
            }

            string localVersion = File.Exists("version.txt") ? File.ReadAllText("version.txt") : string.Empty;
            string remoteVersion = infoJson["SoftwareVersion"]?.ToString() ?? "unknown";
            Console.WriteLine("[+] current RC7 version: " + remoteVersion);
            Console.WriteLine("[+] current RC7 file version: " + (string.IsNullOrEmpty(localVersion) ? "none" : localVersion));

            // Check if RC7.exe exists and version matches
            if (File.Exists(RC7Exe) && localVersion == remoteVersion && !string.IsNullOrEmpty(localVersion))
            {
                Console.WriteLine("[+] you are already up to date, launching RC7...");
                SetDllPath();
                LaunchRC7();
            }
            else
            {
                await ProceedToDownload(infoJson);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[+] an error occurred: {ex.Message}, starting download...");
            await ProceedToDownload(null);
            Thread.Sleep(5000);
        }
    }

    static async Task ProceedToDownload(JObject infoJson)
    {
        Console.WriteLine("[+] new version detected or installation missing!");
        if (infoJson != null && infoJson.ContainsKey("Changelog"))
        {
            Console.WriteLine("[+] changelog for new update below\n");
            Console.WriteLine(infoJson["Changelog"]);
        }
        Console.WriteLine("\n[+] downloading RC7...");
        string downloadUrl = infoJson?["SoftwareUrl"]?.ToString();
        bool downloadSuccess = await DownloadFileWithProgress(downloadUrl, "RC7.zip");

        if (!downloadSuccess)
        {
            Console.WriteLine("[+] download failed, please try again");
            Thread.Sleep(5000);
            return;
        }

        Console.WriteLine("[+] extracting RC7 to C:\\RC7...");
        try
        {
            if (Directory.Exists(RC7Path))
                Directory.Delete(RC7Path, true);
            Directory.CreateDirectory(RC7Path);
            ZipFile.ExtractToDirectory("RC7.zip", RC7Path);
            File.Delete("RC7.zip");
            Console.WriteLine("[+] zip file deleted");

            // Unblock DLLs, fix subfolder, verify DLLs, and set PATH
            UnblockDlls(RC7Path);
            FixSubfolderExtraction(RC7Path);
            VerifyDlls(RC7Path);
            SetDllPath();

            if (infoJson != null)
                File.WriteAllText("version.txt", infoJson["SoftwareVersion"]?.ToString() ?? "unknown");

            LaunchRC7();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[+] error during extraction or launch: {ex.Message}");
            Thread.Sleep(5000);
        }
    }

    static void UnblockDlls(string path)
    {
        try
        {
            foreach (string file in Directory.GetFiles(path, "*.dll", SearchOption.AllDirectories))
            {
                FileInfo fileInfo = new FileInfo(file);
                if (fileInfo.IsReadOnly)
                {
                    fileInfo.IsReadOnly = false;
                }
                FileSecurity fileSecurity = fileInfo.GetAccessControl();
                fileSecurity.AddAccessRule(new FileSystemAccessRule("Everyone", FileSystemRights.FullControl, AccessControlType.Allow));
                fileInfo.SetAccessControl(fileSecurity);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[+] error unblocking DLLs: {ex.Message}");
        }
    }

    static void FixSubfolderExtraction(string path)
    {
        try
        {
            string[] possibleSubfolders = { Path.Combine(path, "RC7"), Path.Combine(path, "rc7"), Path.Combine(path, "bin") };
            foreach (string subfolder in possibleSubfolders)
            {
                if (Directory.Exists(subfolder) && File.Exists(Path.Combine(subfolder, "RC7.exe")))
                {
                    foreach (string file in Directory.GetFiles(subfolder, "*.*", SearchOption.AllDirectories))
                    {
                        string destFile = Path.Combine(path, Path.GetFileName(file));
                        if (File.Exists(destFile))
                            File.Delete(destFile);
                        File.Move(file, destFile);
                    }
                    Directory.Delete(subfolder, true);
                    Console.WriteLine("[+] moved files from subfolder to C:\\RC7");
                    break;
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[+] error fixing subfolder extraction: {ex.Message}");
        }
    }

    static void VerifyDlls(string path)
    {
        try
        {
            string[] expectedDlls = { "AntiSkidDLL.dll", "FastColoredTextBox.dll", "Guna.UI2.dll", "KrystalAPI.dll", "Newtonsoft.Json.dll" };
            bool dllMissing = false;
            foreach (string dll in expectedDlls)
            {
                if (!File.Exists(Path.Combine(path, dll)))
                {
                    Console.WriteLine($"[+] warning: required DLL missing: {dll}");
                    dllMissing = true;
                }
            }
            if (dllMissing)
            {
                Console.WriteLine("[+] some DLLs are missing, please verify RC7.zip contents");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[+] error verifying DLLs: {ex.Message}");
        }
    }

    static void SetDllPath()
    {
        try
        {
            string currentPath = Environment.GetEnvironmentVariable("PATH", EnvironmentVariableTarget.Process);
            if (!currentPath.Contains(RC7Path))
            {
                Environment.SetEnvironmentVariable("PATH", $"{currentPath};{RC7Path}", EnvironmentVariableTarget.Process);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[+] error setting PATH: {ex.Message}");
        }
    }

    static void LaunchRC7()
    {
        try
        {
            if (!File.Exists(RC7Exe))
            {
                Console.WriteLine("[+] error: RC7 executable not found, please try downloading again");
                Thread.Sleep(5000);
                return;
            }

            ProcessStartInfo startInfo = new ProcessStartInfo
            {
                FileName = RC7Exe,
                WorkingDirectory = RC7Path,
                UseShellExecute = true,
                CreateNoWindow = false
            };
            Process process = Process.Start(startInfo);
            if (process != null)
            {
                Console.WriteLine("[+] RC7 launched successfully");
            }
            else
            {
                Console.WriteLine("[+] error: failed to start RC7 process");
                Thread.Sleep(5000);
            }
        }
        catch (Win32Exception ex)
        {
            Console.WriteLine($"[+] error launching RC7: {ex.Message} (Error Code: {ex.NativeErrorCode})");
            Thread.Sleep(5000);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[+] error launching RC7: {ex.Message}");
            Thread.Sleep(5000);
        }
    }

    static async Task SetConsoleTitleFromJson()
    {
        string response = await HttpGet(RbxVersionUrl);
        if (!string.IsNullOrEmpty(response))
        {
            try
            {
                var data = JObject.Parse(response);
                Console.Title = "RC7 | " + (data["clientVersionUpload"]?.ToString() ?? "unknown");
            }
            catch { }
        }
    }

    static async Task<string> HttpGet(string url)
    {
        using (HttpClient client = new HttpClient())
        {
            try
            {
                client.Timeout = TimeSpan.FromSeconds(30);
                return await client.GetStringAsync(url);
            }
            catch (HttpRequestException ex)
            {
                Console.WriteLine($"[+] HTTP error: {ex.Message} (Status code: {ex.StatusCode})");
                return string.Empty;
            }
            catch (TaskCanceledException)
            {
                Console.WriteLine("[+] HTTP error: Request timed out");
                return string.Empty;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[+] HTTP error: {ex.Message}");
                return string.Empty;
            }
        }
    }

    static async Task<bool> DownloadFileWithProgress(string url, string outputPath)
    {
        if (string.IsNullOrEmpty(url))
        {
            Console.WriteLine("[+] invalid download URL");
            return false;
        }

        using (HttpClient client = new HttpClient())
        {
            try
            {
                client.Timeout = TimeSpan.FromSeconds(30);
                using (HttpResponseMessage response = await client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead))
                {
                    response.EnsureSuccessStatusCode();
                    long? totalLength = response.Content.Headers.ContentLength;
                    using (Stream contentStream = await response.Content.ReadAsStreamAsync(),
                           fileStream = new FileStream(outputPath, FileMode.Create, FileAccess.Write, FileShare.None, 8192, true))
                    {
                        var totalRead = 0L;
                        var buffer = new byte[8192];
                        int read;
                        int lastProgress = -1;

                        while ((read = await contentStream.ReadAsync(buffer, 0, buffer.Length)) > 0)
                        {
                            await fileStream.WriteAsync(buffer, 0, read);
                            totalRead += read;

                            if (totalLength.HasValue)
                            {
                                int progress = (int)((totalRead * 100) / totalLength.Value);
                                if (progress > lastProgress)
                                {
                                    lastProgress = progress;
                                    int barLength = 20;
                                    int filled = (int)(barLength * progress / 100.0);
                                    string bar = new string('#', filled) + new string('.', barLength - filled);
                                    Console.Write($"\r[+] downloading RC7: [{bar}] {progress}%");
                                }
                            }
                        }
                        Console.WriteLine();
                    }
                }
                return true;
            }
            catch (HttpRequestException ex)
            {
                Console.WriteLine($"\n[+] failed to download file: {ex.Message} (Status code: {ex.StatusCode})");
                return false;
            }
            catch (TaskCanceledException)
            {
                Console.WriteLine("\n[+] failed to download file: Request timed out");
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\n[+] failed to download file: {ex.Message}");
                return false;
            }
        }
    }

    static void PrintAsciiArt()
    {
        Console.ForegroundColor = ConsoleColor.DarkRed;
        Console.WriteLine(@" _______  _______  ______ ");
        Console.WriteLine(@"(  ____ )(  ____ \/ ___  \ ");
        Console.WriteLine(@"| (    )|| (    \/\/   )  )");
        Console.WriteLine(@"| (____)|| |          /  / ");
        Console.WriteLine(@"|     __)| |         /  /  ");
        Console.WriteLine(@"| (\ (   | |        /  /   ");
        Console.WriteLine(@"| ) \ \__| (____/\ /  /    ");
        Console.WriteLine(@"|/   \__/(_______/ \_/     ");
        Console.ForegroundColor = ConsoleColor.White;
    }
}