﻿using System;
using System.Runtime.InteropServices;
using System.Threading;
using System.Diagnostics;
using System.IO;
using System.Net;

namespace KeyboardMouseLock
{
    class Program
    {
        [DllImport("user32.dll", SetLastError = true)][return: MarshalAs(UnmanagedType.Bool)] public static extern bool BlockInput(bool fBlockIt);

        [DllImport("user32.dll", SetLastError = true)]
        public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);

        [DllImport("user32.dll", SetLastError = true)]
        public static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        public static extern int MessageBoxW(IntPtr hWnd, string lpText, string lpCaption, uint uType);

        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        public static extern IntPtr FindWindowW(string lpClassName, string lpWindowName);

        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool PostMessageW(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

        private const byte VK_LWIN = 0x5B;
        private const byte VK_R = 0x52;
        private const byte VK_RETURN = 0x0D;
        private const uint KEYEVENTF_KEYUP = 0x0002;
        private const uint KEYEVENTF_UNICODE = 0x0004;
        private const uint WM_CLOSE = 0x0010;
        private const uint MB_OK = 0x00000000;
        private const uint MB_ICONINFORMATION = 0x00000040;

        [StructLayout(LayoutKind.Sequential)]
        public struct INPUT
        {
            public uint type;
            public INPUTUNION u;
        }

        [StructLayout(LayoutKind.Explicit)]
        public struct INPUTUNION
        {
            [FieldOffset(0)]
            public MOUSEINPUT mi;
            [FieldOffset(0)]
            public KEYBDINPUT ki;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct KEYBDINPUT
        {
            public ushort wVk;
            public ushort wScan;
            public uint dwFlags;
            public uint time;
            public UIntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct MOUSEINPUT
        {
            public int dx;
            public int dy;
            public uint mouseData;
            public uint dwFlags;
            public uint time;
            public UIntPtr dwExtraInfo;
        }

        private static void SendUnicodeChar(char c)
        {
            INPUT[] inputs = new INPUT[2];
            inputs[0] = new INPUT
            {
                type = 1,
                u = new INPUTUNION
                {
                    ki = new KEYBDINPUT
                    {
                        wVk = 0,
                        wScan = c,
                        dwFlags = KEYEVENTF_UNICODE,
                        dwExtraInfo = UIntPtr.Zero
                    }
                }
            };
            inputs[1] = new INPUT
            {
                type = 1,
                u = new INPUTUNION
                {
                    ki = new KEYBDINPUT
                    {
                        wVk = 0,
                        wScan = c,
                        dwFlags = KEYEVENTF_UNICODE | KEYEVENTF_KEYUP,
                        dwExtraInfo = UIntPtr.Zero
                    }
                }
            };
            uint result = SendInput(2, inputs, Marshal.SizeOf(typeof(INPUT)));
            if (result != 2)
            {
                throw new Exception("SendInput başarısız: " + Marshal.GetLastWin32Error());
            }
            Thread.Sleep(30);
        }

        private static void TypeString(string text)
        {
            foreach (char c in text)
            {
                SendUnicodeChar(c);
            }
        }

        private static void SimulateKeyPress(byte keyCode)
        {
            keybd_event(keyCode, 0, 0, UIntPtr.Zero);
            Thread _;

            {
                keybd_event(keyCode, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
                Thread.Sleep(30);
            }
        }

        private static void ShowAndCloseMessageBox(string message, string title, int timeoutMs)
        {
            Thread messageBoxThread = new Thread(() =>
            {
                MessageBoxW(IntPtr.Zero, message, title, MB_OK | MB_ICONINFORMATION);
            });
            messageBoxThread.Start();

            Thread.Sleep(1000);
            IntPtr hWnd = FindWindowW(null, title);
            if (hWnd != IntPtr.Zero)
            {
                Thread.Sleep(timeoutMs);
                PostMessageW(hWnd, WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
            }
            else
            {
                Console.WriteLine("MessageBox penceresi bulunamadı.");
            }
        }

        private static Process DownloadAndPlayFile(string url, string outputPath)
        {
            // Check write permissions to C:\
            try
            {
                string testFile = Path.Combine(Path.GetDirectoryName(outputPath), "test_write.txt");
                File.WriteAllText(testFile, "test");
                File.Delete(testFile);
            }
            catch (UnauthorizedAccessException)
            {
                throw new Exception("C:\\ dizinine yazma izni yok. Programı yönetici olarak çalıştırın.");
            }

            // Download the file using WebClient
            using (WebClient client = new WebClient())
            {
                client.DownloadFile(url, outputPath);
            }

            if (File.Exists(outputPath))
            {
                ProcessStartInfo playInfo = new ProcessStartInfo
                {
                    FileName = outputPath,
                    UseShellExecute = true
                };
                return Process.Start(playInfo);
            }
            else
            {
                throw new Exception("İndirilen dosya bulunamadı: " + outputPath);
            }
        }

        private static void StopAndDeleteFile(Process process, string filePath)
        {
            if (process != null && !process.HasExited)
            {
                process.Kill();
                process.WaitForExit();
            }
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
            }
        }

        static void Main(string[] args)
        {
            Process mediaProcess = null;
            string outputPath = @"C:\rickroll.mp3";

            try
            {
                // Klavye ve fareyi kilitle
                if (!BlockInput(true))
                {
                    throw new Exception("Klavye ve fare kilitlenemedi. Yönetici olarak çalıştırmayı deneyin.");
                }
                Console.WriteLine("Klavye ve fare kilitlendi.");

                // RickRoll MP3 dosyasını indir ve oynat
                string audioUrl = "https://github.com/RobloxScripts490/NO/raw/refs/heads/main/Rick%20Astley%20-%20Never%20Gonna%20Give%20You%20Up%20(Official%20Music%20Video).mp3";
                mediaProcess = DownloadAndPlayFile(audioUrl, outputPath);
                Console.WriteLine("Müzik oynatılıyor.");

                // Windows + R kombinasyonunu simüle et
                Thread.Sleep(1000);
                keybd_event(VK_LWIN, 0, 0, UIntPtr.Zero);
                keybd_event(VK_R, 0, 0, UIntPtr.Zero);
                Thread.Sleep(200);
                keybd_event(VK_R, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
                keybd_event(VK_LWIN, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
                Console.WriteLine("Windows + R simüle edildi.");

                // Çalıştır penceresine "cmd" yaz
                Thread.Sleep(1000);
                TypeString("cmd");
                SimulateKeyPress(VK_RETURN);
                Console.WriteLine("Komut istemi açıldı.");

                // "color a" yaz
                Thread.Sleep(1500);
                TypeString("color a");
                SimulateKeyPress(VK_RETURN);
                Console.WriteLine("color a komutu çalıştırıldı.");

                // "curl ascii.live/rick" yaz
                Thread.Sleep(1000);
                TypeString("curl ascii.live/rick");
                SimulateKeyPress(VK_RETURN);
                Console.WriteLine("curl ascii.live/rick komutu çalıştırıldı.");

                // 10 saniye bekle (ASCII art oynasın)
                Thread.Sleep(20000);

                // Klavye ve fare kilidini aç
                BlockInput(false);
                Console.WriteLine("Klavye ve fare kilidi açıldı.");

                // Oynatmayı durdur ve dosyayı sil
                StopAndDeleteFile(mediaProcess, outputPath);
                Console.WriteLine("Müzik susturuldu ve dosya silindi.");

                // MessageBox göster ve 5 saniye sonra kapat
                ShowAndCloseMessageBox("HAHA RickRollendin!!", "RickRoll", 5000);
                Console.WriteLine("MessageBox gösterildi ve kapatıldı.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Hata oluştu: " + ex.Message);
                BlockInput(false);
                StopAndDeleteFile(mediaProcess, outputPath);
            }
        }
    }

}